n = int(input("Quantos vc tem?"))

if n > 18:
    print("maior de idade")
else:
    print("criança")
