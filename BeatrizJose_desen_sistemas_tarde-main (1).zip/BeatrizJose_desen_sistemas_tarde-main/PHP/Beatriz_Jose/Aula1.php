<!DOCTYPE html>
<html lang="en">

<head>
    <title> Primeiro Programa PHP</title>
</head>

<body>
    <?php
    echo "<h1>Hello World, PHP-7!</h1>";
    ?>
    <?php
    print "teste, beatriz <br>";
    print "Olá,mundo <br>";
    print "Escape 'chars' são os mesmos como <br>";
    print "Você pode ter quebras de linhas em uma string.<br>";
    print 'Uma string pode usar "aspas-duplas". Isso é muito legal<br>';
    print 'Ainda pode se usar apenas aspas simples dessa forma. It\'a cool<br>';
    ?>

    <?php
    //comentario de uma linhda
    #comentario de uma linha
    echo "<h2 align='center'>
            O meu programa esta ecoando corretamente 
            no meu servidor PHP!
            </h2>";
    ?>
    
</body>

</html>