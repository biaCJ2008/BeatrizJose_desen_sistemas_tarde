<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $umidade =91;
    //Testa se $umidade maior que 90. Retorna um booleano 
    $vaiChover = ($umidade<90);
    if ($vaiChover){
        echo "vai chover com toda certeza absoluta na terra. <br>";
    }

    echo"<em>Beatriz Coimbra José</em>"
    ?>
</body>
</html>