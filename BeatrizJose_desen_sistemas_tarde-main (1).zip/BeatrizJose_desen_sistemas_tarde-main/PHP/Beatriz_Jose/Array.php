<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $dias = array('domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sabado');
    echo $dias[1]."<br>";
    print_r($dias);
    echo"<br>";
    var_dump($dias);
    echo"<br>";
    echo"<br>";
    echo "Beatriz Coimbra José";
    ?>
</body>
</html>