<?php
  echo "Olá, PHP rodando!";
?>
