<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="processarDelecao.php" method="POST">
        <label for="id">ID do cliente:</label>
        <input type="number" id="id" name="id" required>
        <button type="submit"> Excluir cliente</button>

    </form>
</body>

</html>