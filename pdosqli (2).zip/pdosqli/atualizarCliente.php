<?php

require_once 'conexao.php';

$conexao = conectarBanco();

// Obtendo o ID via GET 
$idCliente = $_GET['id_cliente'] ?? null;
$cliente = null;
$msgErro = null;

function buscarClientePorId($idCliente, $conexao)
{
    $stmt = $conexao->prepare("SELECT id_cliente, nome, endereco, telefone, email FROM cliente WHERE id_cliente = :id_cliente");
    $stmt->bindParam(":id_cliente", $idCliente, PDO::PARAM_INT);
    $stmt->execute(); // IMPORTANTE
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

if ($idCliente && is_numeric($idCliente)) {
    $cliente = buscarClientePorId($idCliente, $conexao);

    if (!$cliente) {
        $msgErro = "Erro: Cliente não cadastrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Atualizar Cliente</title>
</head>

<body>
    <script>
        function habilitarEdicao(campo) {
            document.getElementById(campo).removeAttribute("readonly");
        }
    </script>

    <h2>Atualizar Cliente</h2>

    <!-- Se houver erro, exibe a mensagem e o campo de busca -->
    <?php if ($msgErro): ?>
        <p style="color:red;"><?= htmlspecialchars($msgErro) ?></p>
        <form action="atualizarCliente.php" method="GET">
            <label for="id_cliente">ID do Cliente</label>
            <input type="number" id="id_cliente" name="id_cliente" required>
            <button type="submit">Buscar</button>
        </form>
    <?php elseif ($cliente): ?>
        <form action="processarAtualizacao.php" method="POST">
            <input type="hidden" name="id_cliente" value="<?= htmlspecialchars($cliente['id_cliente']) ?>">

            <label for="nome">Nome</label>
            <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($cliente['nome']) ?>" readonly onclick="habilitarEdicao('nome')">

            <label for="endereco">Endereço</label>
            <input type="text" id="endereco" name="endereco" value="<?= htmlspecialchars($cliente['endereco']) ?>" readonly onclick="habilitarEdicao('endereco')">

            <label for="telefone">Telefone</label>
            <input type="text" id="telefone" name="telefone" value="<?= htmlspecialchars($cliente['telefone']) ?>" readonly onclick="habilitarEdicao('telefone')">

            <label for="email">E-mail</label>
            <input type="text" id="email" name="email" value="<?= htmlspecialchars($cliente['email']) ?>" readonly onclick="habilitarEdicao('email')">

            <button type="submit">Salvar Alterações</button>
        </form>
    <?php else: ?>
        <!-- Caso nenhum ID tenha sido informado ainda -->
        <form action="atualizarCliente.php" method="GET">
            <label for="id_cliente">ID do Cliente</label>
            <input type="number" id="id_cliente" name="id_cliente" required>
            <button type="submit">Buscar</button>
        </form>
    <?php endif; ?>
</body>
</html>
